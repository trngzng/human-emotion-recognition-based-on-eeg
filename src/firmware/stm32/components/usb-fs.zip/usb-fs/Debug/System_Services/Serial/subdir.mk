################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../System_Services/Serial/sys_serial.c 

OBJS += \
./System_Services/Serial/sys_serial.o 

C_DEPS += \
./System_Services/Serial/sys_serial.d 


# Each subdirectory must supply rules for building sources it contributes
System_Services/Serial/%.o System_Services/Serial/%.su System_Services/Serial/%.cyclo: ../System_Services/Serial/%.c System_Services/Serial/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../USB_Device/App -I../USB_Device/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../System_Services -I../Middlewares -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-System_Services-2f-Serial

clean-System_Services-2f-Serial:
	-$(RM) ./System_Services/Serial/sys_serial.cyclo ./System_Services/Serial/sys_serial.d ./System_Services/Serial/sys_serial.o ./System_Services/Serial/sys_serial.su

.PHONY: clean-System_Services-2f-Serial

